#include <stdio.h>

int main(void) {
  int a = 0, b = 0, c = 0;

  printf("enter the first no.\n");
  scanf("%d", &a);
  printf("enter the second no.\n");
  scanf("%d", &b);
  c = a;
  a = b;
  b = c;
  printf("swap value is first%d second%d\n", a, b);
  return 0;
}